<?php

//////////////////////////////////////////////////////////////
//===========================================================
// WEBUZO CONTROL PANEL
// Inspired by the DESIRE to be the BEST OF ALL
// ----------------------------------------------------------
// Started by: Pulkit
// Date:       10th Jan 2009
// Time:       21:00 hrs
// Site:       https://webuzo.com/ (WEBUZO)
// ----------------------------------------------------------
// Please Read the Terms of Use at https://webuzo.com/terms
// ----------------------------------------------------------
//===========================================================
// (c) Softaculous Ltd.
//===========================================================
//////////////////////////////////////////////////////////////

if(!defined('SOFTACULOUS')){
	die('Hacking Attempt');
}

$l['size'] = 'Size';
$l['name'] = 'Name';
$l['num_users'] = 'Num Users';
$l['uuid'] = 'ID';
$l['add_new'] = 'Add New';
$l['apikeys'] = 'API Keys';
$l['delete'] = 'Delete';
$l['delete_all'] = 'Delete All';
$l['suspend'] = 'Suspend';
$l['unsuspend'] = 'Unsuspend';
$l['owner'] = 'Owner';
$l['ip'] = 'IP';
$l['path'] = 'Path';
$l['user_data_error_t'] = 'User Data Error';
$l['user_data_error'] = APP.' was unable to load your account information. Please report this to the server administrator!';
$l['core_update'] = 'There is an update available for Webuzo v<b>&soft-1;</b>';
$l['wiki_help'] = 'Documentation';
$l['type'] = 'Type';
$l['alert'] = 'Alert';
$l['successful'] = 'Successful';
$l['failed'] = 'Failed';
$l['tasks'] = 'Tasks';
$l['ok'] = 'Ok';
$l['yes'] = 'Yes';
$l['no'] = 'No';
$l['warning'] = 'Warning';
$l['info'] = 'Info';
$l['default'] = 'Default';
$l['disable'] = 'Disable';
$l['enable'] = 'Enable';
$l['used'] = 'Used';
$l['plan'] = 'Plan';
$l['num_res'] = 'Number of Results';
$l['user'] = 'User';

$l['remote_licence_t'] = 'Invalid License';
$l['remote_licence'] = 'You are not using a valid license. Please report this to the server administrator!';

$l['enterprise_licence_t'] = 'Invalid License';
$l['enterprise_licence'] = 'You are not using a valid license. Please report this to the server administrator!';

$l['no_license'] = 'The LICENSE file could not be found! Please report this to the server administrator.';

$l['today'] = '<b>Today</b> at ';//The today string for showing todays post time

$l['init_theme_error_t'] = 'Theme Error';//Title
$l['init_theme_error'] = 'Unable to load the theme file - &soft-1;.';

$l['init_theme_func_error_t'] = 'Theme Function Error';//Title
$l['init_theme_func_error'] = 'Unable to load the theme function(s) of &soft-1;.';

$l['disable_softaculous_t'] = 'Softaculous Disabled';
$l['disable_softaculous'] = 'Softaculous is Disabled for this User. Please contact System Administrator.';

$l['load_theme_settings_error'] = 'Unable to load the themes settings file.';

$l['view_guide'] = 'View Guide';
$l['max_db_length'] = 'The database name cannot be greater than &soft-1; characters. Please choose a shorter database name.';


//Error Handle Function
$l['following_errors_occured'] = 'The following errors were found';

//Success Message Function
$l['following_message'] = 'The following message was returned';

//Major Error Function
$l['fatal_error'] = 'Fatal Error';
$l['following_fatal_error'] = 'The following error occured';

//Message Function
$l['soft_message'] = APP.' Message';
$l['following_soft_message'] = 'The following message was returned';

//Update Softwares
$l['no_soft_found'] = 'Software package not found.....Needs Update';
$l['ver_not_match'] = 'Updated version found.....Needs Update';
$l['ver_match'] = 'Current package version is latest......Continuing';
$l['del_prev_files'] = 'Deleting previous package files......Done';
$l['fetch_latest'] = 'Fetching Latest package......';
$l['error_fetch_latest'] = 'Could not fetch latest package......Continuing';
$l['error_save_latest'] = 'Could not SAVE latest package......';
$l['got_latest'] = 'Saved the Latest package';
$l['unzip_latest'] = 'Unzipping the package files......';
$l['error_unzip_latest'] = 'Error unzipping the package......';
$l['error_unzip_retry'] = 'Retrying';
$l['error_unzip_continue'] = 'Continuing';
$l['unzipped_latest'] = 'Package unzipped Successfully';

//Update Softaculous
$l['getting_info'] = 'Requesting Information......';
$l['error_getting_latest'] = 'Could not get information......Abandoning';
$l['got_info'] = 'Got information';
$l['manual_mode'] = 'The new version of '.APP.' requires manual attention......Abandoning';
$l['no_updates'] = 'Current '.APP.' Version is Latest Version......Continuing';
$l['fetch_upgrade'] = 'Fetching '.APP.' Upgrade package......';
$l['error_fetch_upgrade'] = 'Could not fetch the upgrade package......Abandoning';
$l['error_save_upgrade'] = 'Could not SAVE upgrade package......Abandoning';
$l['got_upgrade'] = 'Saved the Upgrade package';
$l['unzip_upgrade'] = 'Unzipping the files......';
$l['error_unzip_upgrade'] = 'Error unzipping......Abandoning';
$l['unzipped_upgrade'] = 'Unzipped '.APP.' upgrade package Successfully';
$l['md5_check'] = 'MD5 Check Successful';
$l['err_md5_check'] = 'MD5 Check for these files were not Successful';
$l['err_md5_file'] = ' does not exist';

//MySQL Errors
$l['err_selectmy'] = 'The MySQL Database could not be selected.';
$l['err_myconn'] = 'The MySQL Connection could not be established.';
$l['err_makequery'] = 'Could not make the query numbered';
$l['err_mynum'] = 'MySQL Error No';
$l['err_myerr'] = 'MySQL Error';
$l['err_no_db_file'] = 'The database import file does not exist';
$l['err_no_open_db_file'] = 'Could not open the database import file';

//Importing Errors
$l['imp_wrong_softdomain'] = 'The path of the domain &soft-1; could not be found.';
$l['imp_softpath_wrong'] = 'The path of &soft-1; is wrong and does not exist.';
$l['imp_err'] = 'There were some errors while importing the software installed at &soft-1;';
$l['err_query'] = 'Could not execute the query';

$l['invalid_search_input'] = 'Invalid Theme Search character. Only alphanumeric characters, underscore and hyphen are allowed.';

//hf_theme.php
$l['root_login'] = 'Logged in as &soft-1;';
$l['you_admin'] = 'You are the Admin';
$l['welcome'] = 'Welcome';
$l['logout'] = 'Logout';
$l['page_time'] = 'Page Created In';
$l['times_are'] = 'All times are';
$l['time_is'] = 'The time now is';
$l['no_script_found'] = 'No such Script found!';
$l['webuzo_sysapps_disabled'] = 'This functionality has been disabled from the Webuzo Admin Panel';
$l['webuzo_install_utility'] = 'This utility is not installed. Please install it first';
$l['update_exim'] = 'Please update Exim to use this functionality.';

//The Category Language Variables
$l['forums'] = 'Forums';
$l['blogs'] = 'Blogs';
$l['cms'] = 'Portals/CMS';
$l['galleries'] = 'Image Galleries';
$l['wikis'] = 'Wikis';
$l['admanager'] = 'Ad Management';
$l['calendars'] = 'Calendars';
$l['games'] = 'Gaming';
$l['mail'] = 'Mails';
$l['polls'] = 'Polls and Analytics';
$l['projectman'] = 'Project Management';
$l['ecommerce'] = 'E-Commerce';
$l['guestbooks'] = 'Guest Books';
$l['customersupport'] = 'Customer Support';
$l['others'] = 'Others';
$l['music'] = 'Music';
$l['video'] = 'Video';
$l['files'] = 'File Management';
$l['go_cpanel'] = 'Go to Control Panel';
$l['go_home'] = APP.' Home';
$l['go_demos'] = 'Script Demos';
$l['go_ratings'] = 'Script Ratings';
$l['go_settings'] = 'Edit Settings';
$l['go_email_settings'] = 'Email Settings';
$l['go_installations'] = 'All Installations';
$l['go_support'] = 'Help and Support';
$l['go_sync'] = 'Import Installations';
$l['go_backups'] = 'Backups and Restore';
$l['go_tasklist'] = 'Task List';
$l['go_apps_installations'] = 'All Installed Applications';
$l['go_my_themes'] = 'My Themes';
$l['go_logout'] = 'Logout';
$l['ins_stats'] = 'Installations';
$l['outdated_stats'] = 'Outdated Installations';
$l['backups_stats'] = 'Backups';
$l['go_plans'] = 'Plans';
$l['go_wp_manager'] = 'WordPress Manager';

$l['type_php'] = 'PHP';
$l['type_perl'] = 'Perl';
$l['type_js'] = 'JavaScript';
$l['type_java'] = 'Java';
$l['type_python'] = 'Python';
$l['search'] = 'Search';
$l['back_to_top'] = 'Back to Top';

$l['show'] = 'Show';
$l['hide'] = 'Hide';

$l['cat_apps_server_side_scripting'] = 'Server Side Scripting';
$l['cat_apps_web_servers'] = 'Web Servers';
$l['cat_apps_utilities'] = 'Utilities';
$l['cat_apps_libraries'] = 'Libraries';
$l['cat_apps_databases'] = 'Databases';
$l['cat_apps_stacks'] = 'Stacks';
$l['cat_apps_security'] = 'Security';
$l['cat_apps_statistics'] = 'Statistics';
$l['cat_apps_java_tools'] = 'Java Tools';
$l['cat_apps_java_containers'] = 'Java Containers';
$l['cat_apps_version_control'] = 'Version Control';
$l['cat_apps_modules'] = 'Modules';
$l['cat_apps_message_queue'] = 'Message Queue';

// Softaculous Remote Domain Strings
$l['no_domain_data'] = 'Domain Data Not Found!!';

// Webuzo Strings
$l['webuzo'] = 'Webuzo';
$l['go_domain'] = 'Manage Domains';
$l['webuzo_license_exp'] = 'Your license is not active or it has expired. If your license has expired, please renew it to continue using Webuzo';
$l['webuzo_license_exp_t'] = 'License Inactive';
$l['err_no_access'] = 'You do not have permission to access this page';

/////////////////////////////////////////////////////////////
/////  Following Variables are used for Email Templates /////
/////////////////////////////////////////////////////////////

$l['notify_enable'] = 'Enabled';
$l['notify_disable'] = 'Disabled';

$l['autoupgrade_enable'] = 'Enabled';
$l['autoupgrade_disable'] = 'Disabled';

// Auto backup strings
$l['auto_backup_enable'] = 'Enabled';
$l['auto_backup_disable'] = 'Disabled';

$l['err_openconfig'] = 'Could not open the Configuration File';
$l['err_writeconfig'] = 'Could not write the Configuration File';

$l['classes_con_failed'] = 'Error : Failed to Connect to Server .';
$l['cl_ratings'] = 'Ratings';
$l['cl_author'] = 'Author';
$l['cl_license'] = 'License';
$l['cl_version'] = 'Version';
$l['cl_show_files'] = 'Show Files';
$l['cl_install_but'] = 'Install';
$l['expand_view'] = 'Click here for full view';
$l['collapse_view'] = 'Click here for embedded view';

$l['email_off_notice'] = '<b>NOTE : Notification emails are disabled so you will not receive any email.</b>';

// Requirement parser languages
$l['req_ver_nf'] = 'Required &soft-1; version &soft-2; &soft-3; AND found version is : ';
$l['req_ext_nf'] = 'Required &soft-1; extension not found :';
$l['req_func_nf'] = 'Required &soft-1; function not found';
$l['req_ext_ver'] = 'Required &soft-1; &soft-2; extension version &soft-3; &soft-4; BUT found &soft-5;';
$l['gt'] = 'greater than';
$l['lt'] = 'less than';
$l['ge'] = 'greater than equal to';
$l['le'] = 'less than equal to';
$l['eq'] = 'is';
$l['ne'] = 'should not be equal to';
$l['req_version'] = 'Version';
$l['req_extensions'] = 'Extensions';
$l['req_functions'] = 'Functions';

// Softpanel Language Strings
$l['no_www_domain'] = 'Please close all '.$globals['sn'].' pages and log out from the control panel using the log out button.
Afterwards you can log in again and use '.$globals['sn'].'.';

$l['install_tweet'] = 'I just installed #[[SCRIPTNAME]] on [[softurl]] via #[[APP]] #[[TYPE]]';
$l['install_tweet_classes'] = 'I just installed #[[SCRIPTNAME]] via #[[APP]] #[[TYPE]]';
$l['upgrade_tweet'] = 'I just upgraded #[[SCRIPTNAME]] on [[softurl]] via #[[APP]] #[[TYPE]]';
$l['clone_tweet'] = 'I just cloned #[[SCRIPTNAME]] on [[softurl]] via #[[APP]] #[[TYPE]]';

// month strings
$l['January'] = 'January';
$l['February'] = 'February';
$l['March'] = 'March';
$l['April'] = 'April';
$l['May'] = 'May';
$l['June'] = 'June';
$l['July'] = 'July';
$l['August'] = 'August';
$l['September'] = 'September';
$l['October'] = 'October';
$l['November'] = 'November';
$l['December'] = 'December';

$l['invalid_resp'] = 'Invalid response received ';

$l['api_no_resp'] = 'No response received';
$l['api_invalid_resp'] = 'Invalid response received';

$l['not_in_free'] = '<b>&soft-1;</b> cannot be installed in the Free version of '.APP.'.';
$l['upgrade_to_pro'] = '<b><a href="'.$globals['index'].'act=plans" target="_blank" style="text-decoration:none;color:green;">Unlock Premium Features</a></b>';

$l['not_in_expired'] = '<b>&soft-1;</b> cannot be installed because your '.APP.' license has expired.';
$l['renew_pro'] = '<b><a href="'.$globals['index'].'act=plans" target="_blank" style="text-decoration:none;color:green;">Renew the license to use premium features</a></b>';

$l['invalid_license_enduser_server'] = 'This license is not allowed to be used on this server';
$l['invalid_license_enduser_account'] = 'This license is not allowed to be used on this account';

$l['package_error'] = 'There were some errors in installing package.';

$l['empty_mail_q'] = 'Mail queue is empty.';

// Left Panel 
$l['webuzo_domain'] = 'Domain';
$l['domainmanage'] = 'Manage Domains';
$l['domainadd'] = 'Add Domain';
$l['redirects'] = 'Redirects';
$l['advancedns'] = 'DNS Zone Settings';
$l['network_tools'] = 'Network Tools';
$l['extra_conf'] = 'Extra Configuration';
$l['webuzo_multi_php'] = 'MultiPHP Manager';
$l['webuzo_multiphp_ini_editor'] = 'PHP INI Editor';
$l['webuzo_php_pear'] = 'PHP PEAR package';
$l['webuzo_perl'] = 'Perl Modules';

$l['webuzo_mysql'] = 'Database';
$l['dbmanage'] = 'Manage Database';
$l['dbmanage#adddb'] = 'Add Database';
$l['phpmyadmin'] = 'phpMyAdmin';

$l['webuzo_cat_ftp'] = 'FTP';
$l['ftp'] = 'Manage FTP';
$l['ftp_account'] = 'Add FTP Account';
$l['ftp_connections'] = 'FTP Connections';

$l['webuzo_ssl'] = 'SSL';
$l['sslkey'] = 'Private Keys';
$l['sslcsr'] = 'Cert Signing Request';
$l['sslcrt'] = 'Certificate';
$l['install_cert'] = 'Install Certificate';
$l['lets_encrypt'] = 'Lets Encrypt';

$l['webuzo_cat_email'] = 'Email';
$l['email_account'] = 'Email Account';
$l['email_forward'] = 'Email Forwarders';
$l['mxentry'] = 'MX Entry';
$l['rainloop'] = 'Access Email';
$l['email'] = 'Email Settings';
$l['spam_assassin'] = 'Spam Assassin';
$l['email_deliverability'] = 'Email Deliverability';

$l['webuzo_advance_setting'] = 'Advanced settings';
$l['cronjob'] = 'Cron Job';

$l['webuzo_server_setting'] = 'Server Utilities';
$l['filemanager'] = 'File Manager';
$l['webuzo_backup'] = APP.' Backup';
$l['awstats'] = 'AWStats';
$l['login_logs'] = 'Login Logs';
$l['import_cpanel'] = 'Import from cPanel';

$l['webuzo_server_info'] = 'Server Info';
$l['bandwidth'] = 'Bandwidth';
$l['errorlog'] = 'Error Log';
$l['disk'] = 'Disk';

$l['total_domain'] = 'Total Domains';
$l['total_db'] = 'Total Databases';
$l['total_bandwidth'] = 'Total Bandwidth';
$l['disk_used'] = 'Disk Used';

$l['general_info'] = 'General Information';
$l['current_user'] = 'Current User';
$l['primary_dom'] = 'Primary Domain';
$l['ip_addr'] = 'IP Address';
$l['home_dir'] = 'Home Directory';
$l['last_login_ip'] = 'Last Login IP Address';

$l['web_server'] = 'Web Server';
$l['mysql_version'] = 'Database Service';
$l['default_php'] = 'PHP Version';
$l['linux_distro'] = 'Linux Distribution';

$l['apps'] = 'Apps';
$l['install_apps'] = 'Install Apps';
$l['applications'] = 'Applications';
$l['softa'] = 'Softaculous Auto Installer';

// class.webuzo.php lang
$l['user_exists'] = 'User already exists';
$l['add_user_cmd_failed'] = 'The useradd command failed';
$l['user_save_error'] = 'There was an error while writing the user data';
$l['aliases'] = 'Aliases';
$l['alias'] = 'Alias';
$l['unsafe_skeldir'] = 'Skel directory is not safe. hence aborting user creation';

// Page Jump Related :
$l['page_jump_title'] = 'Type the page to jump to';
$l['page_page'] = 'Page';
$l['page_of'] = 'of';
$l['page_go'] = 'Go';	

$l['err_updating_data'] = 'There was an error while updating the data';
$l['error_session_logout'] = 'It seems that your session is expired, please login and try again';
$l['error_occurred'] = 'It seems that there is some internet connectivity issue, please try to refresh the page and try again';

$l['ipv4'] = 'IPv4';
$l['ipv6'] = 'IPv6';
$l['go'] = 'Go';
$l['all'] = 'All';
$l['entries_per_page'] = 'Entries Per Page';
$l['note'] = 'Note';
$l['none'] = 'None';
$l['manage'] = 'Manage';
$l['ms_delete'] = 'Delete';
$l['ms_enable'] = 'Enable';
$l['ms_disable'] = 'Disable';
$l['del_conf'] = 'Are you sure, you want to delete the selected item(s) ?';
$l['with_selected'] = 'With Selected :';
$l['nothing_selected'] = 'Nothing selected !';
$l['no_action'] = 'No Action Selected !';
$l['action_msg'] = 'Please wait, Action in Progress.';
$l['notify_msg'] = 'You will be notified once the Action is Completed.';
$l['action_completed'] = 'The action was completed successfully. Reloading the Page !';
$l['edit'] = 'Edit';
$l['record_edited'] = 'Record edited successfully';
$l['conn_lost'] = 'Oops ... something we lost connection to the server. Please try again !';

// Slave related
$l['slave_not_permitted'] = 'This action is not permitted on the slave !';

// Permissions
$l['not_allowed_title'] = 'Action not permitted !';
$l['err_acl_no_allowed'] = 'This action is not allowed as per your ACL';
$l['inv_act_option'] = 'The action submitted is invalid';

// Task related
$l['task_started'] = 'The task has been started';
$l['started'] = 'Started';
$l['updated'] = 'Updated';
$l['ended'] = 'Ended';
$l['progress'] = 'Progress';
$l['completed'] = 'Completed';
$l['task_error'] = 'There were some errors !';
$l['load_ave'] = 'Load Averages:';
$l['load_ave_title'] = 'Your server\'s 1-minute, 5-minute, and 15-minute load averages';

// User suspensions
$l['error_suspending'] = 'Some error occurred while suspending the user';
$l['error_unsuspending'] = 'Some error occurred while unsuspending the user';

// Message box related
$l['close'] = 'Close';
$l['cancel'] = 'Cancel';
$l['done'] = 'Done';
$l['deleted'] = 'Deleted';
$l['error'] = 'Error';
$l['r_connect_error'] = 'Oops there was an error while connecting to the <strong>Server</strong>';
$l['delete_conf'] = 'Are you sure you want to delete this ?';
$l['no_tbl_rec'] = 'No record exists. Please add one !';

// Domain types
$l['dom_type_addon'] = 'Addon';
$l['dom_type_parked'] = 'Parked';
$l['dom_type_alias'] = 'Alias';
$l['dom_type_subdomain'] = 'Subdomain';
$l['dom_type_primary'] = 'Primary';

// Enduser Icons
$l['webuzo_import_cpanel'] = 'Import From cPanel';
$l['webuzo_web_ftp'] = 'Web FTP';
$l['webuzo_cat_security'] = 'Security';
$l['u_webuzo_cat_email'] = 'Email';
$l['u_webuzo_ssl'] = 'SSL';
$l['u_webuzo_cat_ftp'] = 'FTP';
$l['u_webuzo_domain'] = 'Domain';
$l['webuzo_login_logs'] = 'Login Logs';
$l['nginx_settings'] = 'Nginx Settings';
$l['webuzo_configuration'] = 'Configuration';
$l['webuzo_firewall'] = 'Firewall';
$l['webuzo_csf'] = 'CSF Configuration';
$l['webuzo_lighttpd'] = 'Lighttpd';
$l['webuzo_nginx'] = 'Nginx';
$l['webuzo_php'] = 'PHP';
$l['webuzo_apache'] = 'Apache';
$l['webuzo_mysql_conf'] = 'MySQL';
$l['webuzo_install_cert'] = 'Install Certificate';
$l['webuzo_email_forward'] = 'Email Forwarders';
$l['webuzo_rainloop'] = 'Access Email';
$l['webuzo_server'] = 'Email Server';
$l['webuzo_email_acc'] = 'Email Account';
$l['webuzo_apache_tomcat'] = 'Apache Tomcat';
$l['webuzo_ssh_access'] = 'SSH Access';
$l['webuzo_crt'] = 'Certificates';
$l['webuzo_key'] = 'Private Keys';
$l['webuzo_csr'] = 'Cert Signing Request';
$l['webuzo_security'] = 'Security';
$l['u_webuzo_server_setting'] = 'Server Utilities';
$l['webuzo_filemanager'] = 'File Manager';
$l['webuzo_cron'] = 'Cron Job';
$l['webuzo_awstats'] = 'AWStats';
$l['webuzo_ip_block'] = 'IP Block';
$l['webuzo_api_key'] = 'API Keys';
$l['webuzo_hotlink_protect'] = 'Hotlink Protect';
$l['webuzo_error_log'] = 'Error Log';
$l['webuzo_download_log'] = 'Download Log';
$l['webuzo_services'] = 'Services';
$l['webuzo_mx_entry'] = 'MX Entry';
$l['apache_settings'] = 'Apache Settings';
$l['webuzo_ftp_account'] = 'Add FTP Account';
$l['webuzo_cpu'] = 'CPU';
$l['webuzo_ram'] = 'RAM';
$l['webuzo_disk'] = 'Disk';
$l['webuzo_bandwidth'] = 'Bandwidth';
$l['webuzo_features'] = 'Features';
$l['webuzo_mandom'] = 'Manage Domains';
$l['webuzo_adddom'] = 'Add Domain';
$l['two_factor_auth'] = 'Two Factor Authentication';
$l['webuzo_pass'] = 'Change Password';
$l['tomcat_pass'] = 'Change Tomcat Password';
$l['webuzo_settings'] = 'Edit Settings';
$l['webuzo_email'] = 'Email Settings';
$l['u_email_queue'] = 'Email Queue';
$l['webuzo_email_filter'] = 'Email Filters';
$l['webuzo_email_deliverability'] = 'Email Deliverability';
$l['webuzo_scripts'] = 'Scripts';
$l['webuzo_demos'] = 'Demos';
$l['webuzo_ratings'] = 'Ratings';
$l['webuzo_installations'] = 'All Installations';
$l['webuzo_backups'] = 'Backups';
$l['u_webuzo_mysql'] = 'Database';
$l['webuzo_mandb'] = 'Manage Databases';
$l['webuzo_adddb'] = 'Add Database';
$l['webuzo_adddbuser'] = 'Add Database User';
$l['webuzo_addusertodb'] = 'Add User To Database';
$l['webuzo_currentdb'] = 'Current Databases';
$l['webuzo_currentdbuser'] = 'Current Database Users';
$l['webuzo_phpmyadmin'] = 'phpMyAdmin';
$l['webuzo_remote_mysql_access'] = 'Remote Mysql Access';
$l['webuzo_ftp'] = 'Manage FTP';
$l['webuzo_cpuinfo'] = 'CPU Usage';
$l['webuzo_raminfo'] = 'RAM Usage';
$l['webuzo_diskinfo'] = 'Disk Usage';
$l['webuzo_inodeinfo'] = 'Inode Usage';
$l['webuzo_dbdisk_info'] = 'Database Disk Usage';
$l['webuzo_bandwidthinfo'] = 'Bandwidth Usage';
$l['webuzo_ftpinfo'] = 'FTP Account Usage';
$l['webuzo_emailinfo'] = 'Email Account Usage';
$l['webuzo_dbinfo'] = 'Database Usage';
$l['webuzo_addoninfo'] = 'Addon Domains';
$l['create_addon'] = 'Add Addon Domain';
$l['create_sub_domain'] = 'Subdomains';
$l['subdomain'] = 'Subdomain';
$l['webuzo_parked_info'] = 'Parked Domains';
$l['webuzo_aliases_info'] = 'Alias Domains';
$l['webuzo_autores_info'] = 'Autoresponder';
$l['webuzo_aliasemail_info'] = 'Alias Email';
$l['u_webuzo_advance_setting'] = 'Advanced settings';
$l['webuzo_advance_dns'] = 'DNS Zone Settings';
$l['webuzo_system_utilities'] = 'Default Apps';
$l['webuzo_php_ext'] = 'PHP Extensions';
$l['webuzo_network_tools'] = 'Network Tools';
$l['webuzo_visitors'] = 'Visitors';
$l['u_webuzo_install_utility'] = 'This utility is not installed. Please install it first';
$l['webuzo_pass_protect_dir'] = 'Directory Privacy';
$l['webuzo_install_sysapps'] = 'Install System Applications';
$l['u_webuzo_sysapps_disabled'] = 'This functionality has been disabled from the Webuzo Admin Panel';
$l['webuzo_ftp_connections'] = 'FTP Connections';
$l['webuzo_extra_conf'] = 'Extra Configuration';
$l['webuzo_aliases'] = 'Aliases';
$l['webuzo_apps_updates'] = 'Update Apps';
$l['u_webuzo_backup'] = 'Backup';
$l['webuzo_redirects'] = 'Redirects';
$l['webuzo_exim'] = 'Exim';
$l['lbl_letsencrypt'] = 'Lets Encrypt';
$l['lbl_zerossl'] = 'ZeroSSL';
$l['webuzo_varnish'] = 'Varnish';
$l['webuzo_spam_assassin'] = 'Spam Assassin';
$l['webuzo_email_autoresponders'] = 'Autoresponders';
$l['import_from_webuzo'] = 'Import From Webuzo';
$l['u_mod_security'] = 'ModSecurity';
$l['u_disk_usage'] = 'Disk Usage';
$l['search_classes'] = 'Search Classes';
$l['lighttpd_settings'] = 'Lighttpd Settings';
$l['svn_manager'] = 'SVN Management';
$l['server_reboot'] = 'Server Reboot';
$l['wp_manage_webuzo'] = 'WordPress Manager';
$l['demo_restriction'] = 'Features restricted in demo mode !';
$l['mysql_user_exists'] = 'There is a MySQL user with the same username';
$l['inv_owner_obj'] = 'The object is not owned by you';
$l['webuzo_import'] = 'Import From Webuzo';
$l['add_backup_server'] = 'Add Backup Server';
$l['lblemail'] = 'Add Email Accounts';
$l['imp_ssh'] = 'Import SSH Key';
$l['terminal'] = 'Terminal';
$l['ssh_generate_keys'] = 'SSH Generate Keys';
$l['rb_title'] = 'Backup Configuration';
$l['pass_score_err'] = 'Password strength must be greater than or equal to &soft-1;';
$l['pass_score_req'] = 'Password strength must be greater than or equal to &soft-1;';
$l['enable_all'] = 'Enable All';
$l['disable_all'] = 'Disable All';
$l['webuzo_pgsql_manage'] = 'Manage PostgreSQL';
$l['u_webuzo_pgsql'] = 'PostgreSQL';

$l['global_news'] = 'Global News';
$l['owner_account_news'] = 'Owner News';
$l['reseller_account_news'] = 'Reseller News';
$l['reseller_news'] = 'Admin News';
$l['shell_disabled'] = 'Shell access is disabled for you !';
$l['many_ttyd_sess'] = 'You have more than 5 TTY sessions. Cannot create a new one !';

// Manage service SSL
$l['sc_invalid_cert'] = 'Invalid Certificate specified !';
$l['sc_invalid_priv_key'] = 'Invalid Key Specified !';
$l['sc_invalid_ca_cert'] = 'Invalid CA Bundle specified !';

// Force Password
$l['fp_force_pwd'] = 'Force Password';

// Search related strings !
$l['select_email'] = 'Select Email';
$l['select_user'] = 'Select User';
$l['select_domain'] = 'Select domain';

// Email delivery
$l['track_delivery'] = 'Track Email Delivery';

// Address Importer
$l['address_importer'] = 'Address Importer';

// Default Address
$l['default_address'] = 'Default Address';

// Email Disk Usage
$l['emdu_title'] = 'Email Disk Usage';

// Encryption
$l['encryption_title'] = 'Encryption';

// Email Router
$l['em_ro_title'] = 'Email Router';

// 2FA login
$l['2fa_send_otp_fail'] = 'There was a problem sending your email with the OTP. Please try again or contact the admin';

// Configure Greylisting
$l['configure_greylisting'] = 'Configure Greylisting';

$l['reports'] = 'Reports';