<?php

//////////////////////////////////////////////////////////////
//===========================================================
// WEBUZO CONTROL PANEL
// Inspired by the DESIRE to be the BEST OF ALL
// ----------------------------------------------------------
// Started by: Pulkit
// Date:       10th Jan 2009
// Time:       21:00 hrs
// Site:       https://webuzo.com/ (WEBUZO)
// ----------------------------------------------------------
// Please Read the Terms of Use at https://webuzo.com/terms
// ----------------------------------------------------------
//===========================================================
// (c) Softaculous Ltd.
//===========================================================
//////////////////////////////////////////////////////////////

if(!defined('SOFTACULOUS')){
	die('Hacking Attempt');
}

$l['ss'] = array();

$l['ss']['default'] = 'Default';
$l['ss']['set-default'] = 'Set Default';
$l['ss']['exp-set-default'] = 'Set it as a default service to be used';
$l['ss']['exp-rem-default'] = 'This will remove the installed conflicting default service';
$l['ss']['dep'] = 'Dependencies';
$l['ss']['remove-dep'] = 'Remove Dependent Application(s)';
$l['ss']['exp-remove-dep'] = 'This will recursively remove the installed dependent application(s)';