<?php

function TEST_users(){
	global $SDK;
	echo 'Testing';
	return ['success' => 1];
}