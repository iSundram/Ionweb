<?php

function TEST_domainmanage(){
	global $SDK;
	echo 'Testing';
	return ['success' => 1];
}